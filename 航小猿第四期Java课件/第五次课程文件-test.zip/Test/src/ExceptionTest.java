import java.io.File;
import java.util.Scanner;

/**
 * 自定义异常类
 * @author wuyinan
 *
 */
class MyException extends Exception {
	public MyException(String info) {
		super(info);
	}
}

public class ExceptionTest {

	/**
	 * 这个方法打印a除以b的值
	 * 编辑这个方法使得不抛出算术异常
	 * @param a 被除数
	 * @param b 除数
	 */
	public void testArithmeticException(int a, int b) {
		System.out.println(a/b);
	}
	
	/**
	 * 这个方法打印数组array的第index个元素的值
	 * 编辑这个方法使得不抛出数组越界异常
	 * @param array 数组
	 * @param index 索引
	 */
	public void testArrayIndexOutOfBoundException(int[] array, int index) {
		System.out.println(array[index]);
	}
	
	/**
	 * 这个方法打印字符串s的长度
	 * 编辑这个方法使得不抛出空指针异常
	 * @param s 字符串
	 */
	public void testNullPointerException(String s) {
		System.out.println(s.length());
	}
	
	/**
	 * 这个方法读取一个文件
	 * 编辑这个方法使得不抛出任何异常
	 */
	public void testFileNotFoundException() {
		File file = new File("x");
		Scanner sc = new Scanner(file);
		sc.close();
	}
	
	/**
	 * 这个方法直接扔出一个自定义异常
	 * 编辑这个方法使得不抛出自定义异常
	 */
	public void testMyException() {
		throw new MyException("My Exception");
	}
	
	/**
	 * 这个方法将s解析成其的整数
	 * 编辑这个方法使得不抛出数字格式异常
	 * @param s 字符串
	 */
	public void testNumberFormatException(String s) {
		Integer.parseInt(s);
	}
	
	/**
	 * 这个方法从控制台读入一个数，并将它解析为整型
	 * 编辑这个方法使得不抛出任何异常
	 */
	public void testIOException() {
		System.out.println("Please input a number: ");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String s = br.readLine();
		testNumberFormatException(s);
		br.close();
	}
	
	/**
	 * 不要编辑main方法中的代码
	 * @param args
	 */
	public static void main(String[] args) {
		ExceptionTest test = new ExceptionTest();
		test.testArithmeticException(1, 0);
		test.testArrayIndexOutOfBoundException(new int[]{1, 2}, 233);
		test.testNullPointerException(null);
		test.testFileNotFoundException();
		test.testMyException();
		test.testIOException();
		System.out.println("Congratulations!");
	}
	
}
