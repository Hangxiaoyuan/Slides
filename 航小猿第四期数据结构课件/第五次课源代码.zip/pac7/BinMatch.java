package pac7;

import java.util.Arrays;
import java.util.Vector;

public class BinMatch {
	static int V = 6;	//������
	static Vector<Integer>[] G = new Vector[6];	//ͼ���ڽӱ���ʾ
	static int[] match = new int[6];	//��ƥ��Ķ���
	static boolean[] used = new boolean[6];	//DFS���õ��ķ��ʱ��
	public static void main(String[] args){
		for(int i = 0; i < G.length; i++){
			G[i] = new Vector<Integer>();
		}
		addEdge(0, 1);
		addEdge(0, 3);
		addEdge(2, 1);
		addEdge(2, 5);
		addEdge(4, 3);
		System.out.println(binMatch());
	}
	public static void addEdge(int u, int v){	
		G[u].add(v);
		G[v].add(u);
	}
	public static boolean dfs(int v){	//����dfs������·
		used[v] = true;
		for(int i = 0; i < G[v].size(); i++){
			int u = G[v].get(i);
			int w = match[u];
			if(w < 0 || !used[w] && dfs(w)){
				match[v] = u;
				match[u] = v;
				return true;
			}
		}
		return false;
	}
	public static int binMatch(){	//������ͼ���ƥ��
		int res = 0;
		Arrays.fill(match, -1);
		for(int v = 0; v < V; v++){
			if(match[v] < 0){
				Arrays.fill(used, false);
				if(dfs(v)){
					res++;
				}
			}
		}
		return res;
	}
}


